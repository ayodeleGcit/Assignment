package com.gcit.lms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gcit.lms.domain.Author;
import com.gcit.lms.domain.Book;
import com.gcit.lms.domain.Genre;
import com.gcit.lms.domain.Publisher;



public class BookDAO extends BaseDAO{
	public void insertBook(Book book) throws ClassNotFoundException, SQLException{
		save("insert into  tbl_book(bookId,title,pubId) values (?,?,?)", new Object[] {book.getBookId(),book.getTitle(),book.getPublisher().getPublisherId()});
	}
	
	public void deleteBook(Book book) throws ClassNotFoundException, SQLException{
		save("delete from tbl_book where bookId=?", new Object[] {book.getBookId()});
	}
	public void updateAuthor(Book book) throws ClassNotFoundException, SQLException{
		save("update  tbl_book set title = ? where bookId = ?", new Object[] {book.getTitle(), book.getBookId()});
	}
	public List<Book> readAll() throws ClassNotFoundException, SQLException{
		PreparedStatement pstmt = getConnection().prepareStatement("select * from tbl_book");
		List<Book> book = new ArrayList<Book>();
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			Book a = new Book();
			a.setBookId(rs.getInt("bookId"));
			a.setTitle(rs.getString("title"));
			Publisher d=new PublisherDAO().getPublisher(rs.getInt("pubId"));
			 a.setPublisher(d);
			 
			List<Author> books = (List<Author>) read("select * from tbl_author where authorId IN (select authorId from tbl_book_authors where bookId =  ?",new Object[]{rs.getInt("bookId")});
			  a.setAuthors(books);
			 List<Genre> g = (List<Genre>) read("select * from tbl_genere where genere_id IN (select genereId from tbl_book_generes where bookId =  ?",new Object[]{rs.getInt("bookId")});
			 if(!g.isEmpty()){
			 a.setGenres(g);
			 }
			book.add(a);
		}
		return book;
	}

	@Override
	public List<?> extractData(ResultSet rs) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		List<Book> book = new ArrayList<Book>();
		while(rs.next()){
			Book a = new Book();
			a.setBookId(rs.getInt("bookId"));
			a.setTitle(rs.getString("title"));
			Publisher d=new PublisherDAO().getPublisher(rs.getInt("pubId"));
			 a.setPublisher(d);
			 List<Author> books = (List<Author>) read("select * from tbl_author where authorId IN (select authorId from tbl_book_authors where bookId =  ?",new Object[]{rs.getInt("bookId")});
			  a.setAuthors(books);
			 List<Genre>g=(List<Genre>) read("select * from tbl_genere where genere_id IN (select genereId from tbl_book_generes where bookId =  ?",new Object[]{rs.getInt("bookId")});
			 a.setGenres(g);
			book.add(a);
			
		}
		return book;
	}

}
