package com.gcit.lms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gcit.lms.domain.Book;
import com.gcit.lms.domain.Publisher;




public class PublisherDAO extends BaseDAO {
	public void insertBook(Publisher p) throws ClassNotFoundException, SQLException{
		save("insert into  tbl_publisher(publisherName,publisherAddress,publisherPhone) values (?,?,?)", new Object[] {p.getPublisherName(),p.getPublisherAddress(),p.getPublisherPhone()});
	}
	
	public void deleteBook(Publisher p) throws ClassNotFoundException, SQLException{
		save("delete from tbl_publisher where publisherId=?", new Object[] {p.getPublisherId()});
	}
	public void updateAuthor(Publisher p) throws ClassNotFoundException, SQLException{
		save("update  tbl_publisher set publisherName = ?,publisherAddress = ?,publisherPhone = ? where publisherId = ?", new Object[] {p.getPublisherId()});
	}
    public Publisher getPublisher(int id) throws ClassNotFoundException, SQLException{
    	Publisher p=new Publisher();
    	String query="Select * from tbl_publisher where publisherId = ?";
    	PreparedStatement ptsmt=getConnection().prepareStatement(query);
    	ptsmt.setInt(1, id);
    	ResultSet rs=ptsmt.executeQuery();
    	while(rs.next()){
    		p.setPublisherId(rs.getInt("publisherId"));
    		p.setPublisherName(rs.getString("publisherName"));
    		p.setPublisherPhone(rs.getString("publisherPhone"));
    		p.setPublisherAddress(rs.getString("publishAddress"));
    	}
		return p;
    	
    }
    public List<Publisher> readAll() throws ClassNotFoundException, SQLException{
    	String query="Select * from tbl_publisher";
    	List<Publisher> pList = new ArrayList<Publisher>();
    	PreparedStatement ptsmt=getConnection().prepareStatement(query);
    	ResultSet rs=ptsmt.executeQuery();
    	while(rs.next()){
    		Publisher p=new Publisher();
    		p.setPublisherId(rs.getInt("publisherId"));
    		p.setPublisherName(rs.getString("publisherName"));
    		p.setPublisherPhone(rs.getString("publisherPhone"));
    		p.setPublisherAddress(rs.getString("publishAddress"));
    		pList.add(p);
    	}
    	return pList;
    	
    	
    }
	@Override
	public List<?> extractData(ResultSet rs) throws SQLException {
		// TODO Auto-generated method stub
		List<Publisher> pub = new ArrayList<Publisher>();
		while(rs.next()){
			Publisher p=new Publisher();
    		p.setPublisherId(rs.getInt("publisherId"));
    		p.setPublisherName(rs.getString("publisherName"));
    		p.setPublisherPhone(rs.getString("publisherPhone"));
    		p.setPublisherAddress(rs.getString("publishAddress"));
    		pub.add(p);
		}
		
		return pub;
	}
}
