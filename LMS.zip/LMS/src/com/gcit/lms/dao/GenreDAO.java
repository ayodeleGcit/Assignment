package com.gcit.lms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gcit.lms.domain.Book;
import com.gcit.lms.domain.Genre;



public class GenreDAO extends BaseDAO {

	public void insertGenre(Genre genre) throws ClassNotFoundException, SQLException{
		save("insert into tbl_genre (genre_name) values (?)", new Object[] {genre.getGenre_name()});
	}
	
	public void deleteGenre(Genre genre) throws ClassNotFoundException, SQLException{
		save("delete from tbl_genre where genre_Id=?", new Object[] {genre.getGenre_id()});
	}
	
	public void deleteAll() throws ClassNotFoundException, SQLException{
		save("delete * from tbl_genre", null);
	}
	
	public void updateGenre(Genre genre) throws ClassNotFoundException, SQLException{
		save("update  tbl_genre set genre_name = ? where genre_Id = ?", new Object[] {genre.getGenre_name(), genre.getGenre_id()});
	}
	public List<Genre> readAll() throws ClassNotFoundException, SQLException{
		PreparedStatement pstmt = getConnection().prepareStatement("select * from tbl_genre");
		List<Genre> genre = new ArrayList<Genre>();
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			Genre g=new Genre();
			g.setGenre_id(rs.getInt("genre_id"));
			g.setGenre_name(rs.getString("genre_name"));
			List<Book> books = (List<Book>) read("select * from tbl_book where bookId IN (select bookId from tbl_book_genres where genre_id =  ?",new Object[]{rs.getInt("genre_id")});
			 if(!books.isEmpty()){
				 g.setBooks(books);
			 }
			 genre.add(g);
		}
		return genre;
	}

	@Override
	public List<?> extractData(ResultSet rs) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		List<Genre> genre = new ArrayList<Genre>();
		
		while(rs.next()){
			Genre g=new Genre();
			g.setGenre_id(rs.getInt("genre_id"));
			g.setGenre_name(rs.getString("genre_name"));
			List<Book> books = (List<Book>) read("select * from tbl_book where bookId IN (select bookId from tbl_book_genres where genre_id =  ?",new Object[]{rs.getInt("genre_id")});
			 if(!books.isEmpty()){
				 g.setBooks(books);
			 }
			 genre.add(g);
		}
		return genre;
		
	}
	
}
